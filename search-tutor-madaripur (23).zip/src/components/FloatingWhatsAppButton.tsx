import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { formatWhatsAppDirectLink } from '../utils/tutorEngine';
import { Language } from '../types/madaripur';

export interface FloatingWhatsAppButtonProps {
  whatsappContact?: string;
  lang?: Language;
}

export const FloatingWhatsAppButton: React.FC<FloatingWhatsAppButtonProps> = ({
  whatsappContact = '01715380022',
  lang = 'en',
}) => {
  const [showTooltip, setShowTooltip] = useState(true);

  const directLink = formatWhatsAppDirectLink(whatsappContact);

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-2 group">
      {/* Tooltip Popup Badge */}
      {showTooltip && (
        <div className="relative flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-stone-900 text-white text-xs font-bold shadow-xl border border-stone-800 animate-bounce duration-1000">
          <span className="w-2 h-2 rounded-full bg-[#25D366] animate-ping" />
          <span>
            {lang === 'en'
              ? 'Need Help? Chat on WhatsApp'
              : 'সাহায্য প্রয়োজন? হোয়াটসঅ্যাপে কথা বলুন'}
          </span>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
            className="ml-1 p-0.5 rounded-full hover:bg-stone-800 text-stone-400 hover:text-white transition-colors cursor-pointer"
            aria-label="Dismiss WhatsApp popup"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Floating Action Button */}
      <a
        href={directLink}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Live WhatsApp Support Chat"
        title="Live WhatsApp Support Chat"
        className="relative flex items-center justify-center w-14 h-14 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white shadow-xl hover:shadow-2xl hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer border-2 border-white/20"
      >
        <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-25" />
        
        {/* Official WhatsApp SVG Logo */}
        <svg
          className="w-8 h-8 fill-current relative z-10"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path d="M12.031 2c-5.516 0-9.969 4.453-9.969 9.969 0 1.766.469 3.484 1.359 4.984L2 22l5.188-1.359c1.453.797 3.109 1.219 4.843 1.219 5.516 0 9.969-4.453 9.969-9.969S17.547 2 12.031 2zm5.828 14.125c-.25.703-1.438 1.344-2.016 1.438-.531.094-1.234.141-1.984-.094-.469-.141-1.063-.344-1.828-.672-3.219-1.391-5.313-4.641-5.469-4.859-.156-.219-1.313-1.75-1.313-3.344 0-1.594.828-2.375 1.125-2.703.297-.328.641-.406.859-.406.219 0 .422.016.609.016.203 0 .469-.078.734.563.266.656.906 2.219.984 2.375.078.156.125.344.016.563-.109.219-.156.344-.313.531-.156.188-.328.406-.469.547-.156.156-.328.328-.141.641.188.313.828 1.375 1.781 2.219 1.219 1.094 2.25 1.438 2.563 1.594.313.156.5.125.688-.078.188-.203.797-.938 1.016-1.25.219-.313.422-.266.719-.156.297.109 1.875.891 2.203 1.047.328.156.547.234.625.375.078.141.078.813-.172 1.516z" />
        </svg>
      </a>
    </div>
  );
};
