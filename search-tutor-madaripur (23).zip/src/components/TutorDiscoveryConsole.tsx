import React from 'react';
import {
  MADARIPUR_UPAZILAS,
  UPAZILA_LABELS,
} from '../data/madaripurData';
import {
  CollegeTag,
  FilterState,
  Language,
  MediumCategory,
  TutorGender,
  TutorProfile,
  Upazila,
} from '../types/madaripur';
import { formatBDT, toBanglaNumber } from '../utils/tutorEngine';
import { TutorPortraitSvg } from './TutorPortraitSvg';
import {
  CalendarCheck,
  CheckCircle2,
  Clock,
  FileText,
  Heart,
  MessageSquarePlus,
  RotateCcw,
  Search,
  ShieldAlert,
  ShieldCheck,
  SlidersHorizontal,
  Star,
  Trash2,
} from 'lucide-react';

interface TutorDiscoveryConsoleProps {
  lang: Language;
  filters: FilterState;
  onUpdateFilters: (partial: Partial<FilterState>) => void;
  onResetFilters: () => void;
  filteredTutors: TutorProfile[];
  totalTutorsCount: number;
  shortlistedIds: string[];
  onToggleShortlist: (tutorId: string) => void;
  bookedTutorIds: string[];
  onOpenProfileModal: (tutor: TutorProfile) => void;
  onOpenTrialModal: (tutor: TutorProfile) => void;
  onDeleteTutor: (tutorId: string) => void;
  onClearTutorDesk: () => void;
  onSwitchToUploadDesk: () => void;
}

const COLLEGE_TAGS: CollegeTag[] = [
  'All',
  'Govt. Nazimuddin College',
  'Madaripur Govt. College',
  'DU',
  'BUET',
  'Medical',
];

const COLLEGE_LABELS_BN: Record<CollegeTag, string> = {
  All: 'সকল প্রতিষ্ঠান',
  'Govt. Nazimuddin College': 'সরকারি নাজিমউদ্দিন কলেজ',
  'Madaripur Govt. College': 'মাদারীপুর সরকারি কলেজ',
  DU: 'ঢাকা বিশ্ববিদ্যালয় (DU)',
  BUET: 'বুয়েট (BUET)',
  Medical: 'মেডিকেল কলেজ',
};

const MEDIUM_CATEGORIES: MediumCategory[] = [
  'All',
  'Bangla Medium',
  'English Version',
  'Admission Test',
  'Madrasah/Quranic',
  'ICT',
];

const MEDIUM_LABELS_BN: Record<MediumCategory, string> = {
  All: 'সকল মিডিয়াম',
  'Bangla Medium': 'বাংলা মিডিয়াম',
  'English Version': 'ইংলিশ ভার্সন',
  'Admission Test': 'ভর্তি পরীক্ষা',
  'Madrasah/Quranic': 'মাদ্রাসা / কুরআন',
  ICT: 'আইসিটি স্পেশাল',
};

export const TutorDiscoveryConsole: React.FC<TutorDiscoveryConsoleProps> = ({
  lang,
  filters,
  onUpdateFilters,
  onResetFilters,
  filteredTutors,
  totalTutorsCount,
  shortlistedIds,
  onToggleShortlist,
  bookedTutorIds,
  onOpenProfileModal,
  onOpenTrialModal,
  onDeleteTutor,
  onClearTutorDesk,
  onSwitchToUploadDesk,
}) => {
  const [isFilterOpen, setIsFilterOpen] = React.useState(false);
  const allUpazilas: Upazila[] = ['All', ...MADARIPUR_UPAZILAS];

  const activeFiltersCount =
    (filters.upazila !== 'All' ? 1 : 0) +
    (filters.medium !== 'All' ? 1 : 0) +
    (filters.gender !== 'All' ? 1 : 0) +
    (filters.college !== 'All' ? 1 : 0) +
    (filters.maxBudget < 10000 ? 1 : 0) +
    (filters.verifiedOnly ? 1 : 0);

  return (
    <section
      id="tutor-console"
      aria-label="Tutor Board"
      className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10"
    >
      {/* Editorial Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <span className="text-xs font-semibold text-[#047857] dark:text-emerald-400 block mb-1">
            {lang === 'en'
              ? 'Tutor Zone · Verified Educators Directory · Institution, Hub & Budget Filters'
              : 'টিউটর জোন · যাচাইকৃত শিক্ষক ডিরেক্টরি · প্রতিষ্ঠান, এলাকা ও বাজেট ফিল্টার'}
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-stone-900 dark:text-stone-50">
            {lang === 'en' ? 'Tutor Board' : 'টিউটর বোর্ড (Tutor Board)'}
          </h2>
        </div>

        <div className="flex items-center gap-3 text-xs text-stone-600 dark:text-stone-400">
          <span>
            {lang === 'en' ? 'Showing' : 'প্রদর্শিত হচ্ছে'}{' '}
            <strong className="font-mono-num text-stone-900 dark:text-white">
              {lang === 'bn'
                ? toBanglaNumber(filteredTutors.length)
                : filteredTutors.length}
            </strong>{' '}
            {lang === 'en' ? 'tutors' : 'জন টিউটর'}
          </span>
          <span aria-hidden="true">·</span>
          <button
            type="button"
            onClick={onResetFilters}
            className="inline-flex items-center gap-1 font-semibold text-[#047857] dark:text-emerald-400 hover:underline whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'Reset All Filters' : 'ফিল্টার রিসেট'}</span>
          </button>
          {totalTutorsCount > 0 && (
            <>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={onClearTutorDesk}
                className="inline-flex items-center gap-1 font-semibold text-red-600 dark:text-red-400 hover:underline whitespace-nowrap shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>
                  {lang === 'en'
                    ? 'Clear Tutor Desk Only'
                    : 'শুধু টিউটর ডেস্ক মুছুন'}
                </span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Sleek Ultra-Compact Tutor Filter Deck (Hidden by Default on Mobile & Desktop) */}
      <div className="p-2.5 bg-white dark:bg-stone-900 rounded-2xl border border-slate-200/90 dark:border-stone-800 shadow-xs mb-6 sm:mb-8">
        {/* 1. Default Ultra-Compact Top Bar (Single Slim Row) */}
        <div className="flex items-center gap-2">
          {/* Slim Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="tutor-search-input"
              type="text"
              placeholder={
                lang === 'en'
                  ? 'Search Subject, College, or Landmark...'
                  : 'বিষয়, কলেজ বা এলাকার নাম লিখে খুঁজুন...'
              }
              value={filters.searchQuery}
              onChange={(e) =>
                onUpdateFilters({ searchQuery: e.target.value })
              }
              className="w-full pl-10 pr-3.5 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-stone-800 border border-slate-200 dark:border-stone-700 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:border-[#047857]"
            />
          </div>

          {/* Reset Button (Visible when filters are active) */}
          {(activeFiltersCount > 0 || Boolean(filters.searchQuery.trim())) && (
            <button
              type="button"
              onClick={onResetFilters}
              className="text-xs font-bold text-[#047857] dark:text-emerald-400 hover:underline px-1.5 py-1 whitespace-nowrap shrink-0 transition-colors"
            >
              {lang === 'en' ? 'Reset' : 'রিসেট'}
            </button>
          )}

          {/* Bold, Modern "⚙️ Filter" Toggle Button */}
          <button
            type="button"
            onClick={() => setIsFilterOpen((prev) => !prev)}
            aria-expanded={isFilterOpen}
            className="px-3.5 py-2 rounded-xl font-bold text-xs sm:text-sm bg-emerald-700 hover:bg-emerald-800 text-white flex items-center gap-1.5 shrink-0 transition-all shadow-xs cursor-pointer"
          >
            <span>⚙️</span>
            <span>{lang === 'en' ? 'Filter' : 'ফিল্টার'}</span>
            {activeFiltersCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-white text-emerald-800 text-[10px] font-extrabold flex items-center justify-center shrink-0">
                {activeFiltersCount}
              </span>
            )}
            <span className="text-[10px] ml-0.5">
              {isFilterOpen ? '▲' : '▼'}
            </span>
          </button>
        </div>

        {/* 2. Collapsible Compact Filter Drawer (Opens ONLY When "⚙️ Filter" is Clicked) */}
        {isFilterOpen && (
          <div className="mt-2.5 p-3 bg-slate-50/80 dark:bg-stone-800/80 rounded-xl border border-slate-200/80 dark:border-stone-700/80 space-y-2.5">
            {/* Row 1 (Compact Grid): Upazila / Area Hub, Medium / Category, Tutor Gender */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {/* Upazila / Area Hub */}
              <div>
                <label
                  htmlFor="upazila-select"
                  className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-stone-400 mb-1"
                >
                  {lang === 'en' ? 'Upazila / Area Hub' : 'উপজেলা / এলাকা'}
                </label>
                <select
                  id="upazila-select"
                  value={filters.upazila}
                  onChange={(e) =>
                    onUpdateFilters({ upazila: e.target.value as Upazila })
                  }
                  className="w-full py-1.5 px-2.5 text-xs font-semibold rounded-lg bg-white dark:bg-stone-800 border border-slate-200 dark:border-stone-700 text-stone-900 dark:text-stone-100 focus:outline-none focus:border-[#047857]"
                >
                  {allUpazilas.map((u) => (
                    <option key={u} value={u}>
                      {lang === 'en' ? UPAZILA_LABELS[u].en : UPAZILA_LABELS[u].bn}
                    </option>
                  ))}
                </select>
              </div>

              {/* Medium / Category */}
              <div>
                <label
                  htmlFor="medium-select"
                  className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-stone-400 mb-1"
                >
                  {lang === 'en' ? 'Medium / Category' : 'মিডিয়াম / বিভাগ'}
                </label>
                <select
                  id="medium-select"
                  value={filters.medium}
                  onChange={(e) =>
                    onUpdateFilters({ medium: e.target.value as MediumCategory })
                  }
                  className="w-full py-1.5 px-2.5 text-xs font-semibold rounded-lg bg-white dark:bg-stone-800 border border-slate-200 dark:border-stone-700 text-stone-900 dark:text-stone-100 focus:outline-none focus:border-[#047857]"
                >
                  {MEDIUM_CATEGORIES.map((m) => (
                    <option key={m} value={m}>
                      {lang === 'en' ? m : MEDIUM_LABELS_BN[m]}
                    </option>
                  ))}
                </select>
              </div>

              {/* Tutor Gender */}
              <div className="col-span-2 sm:col-span-1">
                <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-stone-400 mb-1">
                  {lang === 'en' ? 'Tutor Gender' : 'শিক্ষকের লিঙ্গ'}
                </span>
                <div
                  role="group"
                  aria-label="Tutor gender filter"
                  className="grid grid-cols-3 p-0.5 rounded-lg bg-white dark:bg-stone-800 border border-slate-200 dark:border-stone-700"
                >
                  {(['All', 'Male', 'Female'] as TutorGender[]).map((g) => {
                    const active = filters.gender === g;
                    const label =
                      lang === 'en'
                        ? g
                        : g === 'All'
                        ? 'সবাই'
                        : g === 'Male'
                        ? 'পুরুষ'
                        : 'মহিলা';
                    return (
                      <button
                        key={g}
                        type="button"
                        onClick={() => onUpdateFilters({ gender: g })}
                        className={`py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap text-center ${
                          active
                            ? 'bg-[#047857] text-white shadow-xs'
                            : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Row 2: Single-Line Institution Chips & Slim Fee Slider */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2 border-t border-slate-200/80 dark:border-stone-700/80 items-center">
              {/* Institution / College Filter */}
              <div className="md:col-span-7">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-stone-400">
                    {lang === 'en'
                      ? 'Institution / College Filter'
                      : 'প্রতিষ্ঠান / কলেজ ফিল্টার'}
                  </span>
                </div>
                <div
                  role="group"
                  aria-label="Filter by College or University"
                  className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 whitespace-nowrap"
                >
                  {COLLEGE_TAGS.map((col) => {
                    const active = filters.college === col;
                    return (
                      <button
                        key={col}
                        type="button"
                        onClick={() => onUpdateFilters({ college: col })}
                        className={`px-3 py-1 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                          active
                            ? 'bg-[#047857] text-white border-[#047857] shadow-xs'
                            : 'bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300 border-slate-200 dark:border-stone-700 hover:border-[#047857]/50'
                        }`}
                      >
                        {lang === 'en' ? col : COLLEGE_LABELS_BN[col]}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Max Monthly Fee Slider + Verified Badge */}
              <div className="md:col-span-5 flex flex-col justify-center">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-stone-400 flex items-center gap-1">
                    <SlidersHorizontal className="w-3 h-3 text-[#047857]" />
                    <span>
                      {lang === 'en' ? 'Max Monthly Fee' : 'সর্বোচ্চ মাসিক ফি'}
                    </span>
                  </span>
                  <span className="font-mono-num font-bold text-[#047857] dark:text-emerald-400 text-xs">
                    {formatBDT(filters.maxBudget, lang)}
                  </span>
                </div>
                <div className="flex items-center gap-2.5">
                  <input
                    id="budget-slider"
                    type="range"
                    min={2000}
                    max={10000}
                    step={500}
                    value={filters.maxBudget}
                    onChange={(e) =>
                      onUpdateFilters({ maxBudget: Number(e.target.value) })
                    }
                    className="w-full cursor-pointer h-1.5 bg-stone-200 dark:bg-stone-700 rounded-lg accent-[#047857]"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateFilters({ verifiedOnly: !filters.verifiedOnly })
                    }
                    aria-pressed={filters.verifiedOnly}
                    className={`px-2.5 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 ${
                      filters.verifiedOnly
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-[#047857] text-[#047857] dark:text-emerald-300 font-bold'
                        : 'bg-white dark:bg-stone-800 border-slate-200 dark:border-stone-700 text-stone-700 dark:text-stone-300'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-[#047857] dark:text-emerald-400 shrink-0" />
                    <span>{lang === 'en' ? 'Verified' : 'ভেরিফায়েড'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Tutor Profile Cards Grid */}
      {filteredTutors.length === 0 ? (
        <div className="rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 p-12 text-center">
          <p className="text-base font-bold text-stone-900 dark:text-white mb-2">
            {totalTutorsCount === 0
              ? lang === 'en'
                ? 'All tutor records have been cleared (0 tutors in directory).'
                : 'সকল টিউটর ডাটা মুছে ফেলা হয়েছে (তালিকায় ০ জন টিউটর)।'
              : lang === 'en'
              ? 'No Madaripur tutors match your exact filter combination.'
              : 'আপনার নির্বাচিত ফিল্টারে কোনো টিউটর পাওয়া যায়নি।'}
          </p>
          <p className="text-sm text-stone-600 dark:text-stone-400 mb-5">
            {totalTutorsCount === 0
              ? lang === 'en'
                ? 'Submit a new tutor profile with NID & University credentials in Profile and approve it in Admin Review to list a verified tutor.'
                : 'প্রোফাইলে নতুন টিউটরের এনআইডি ও কলেজের তথ্য জমা দিয়ে অ্যাডমিন রিভিউতে অনুমোদন করলে এখানে প্রদর্শিত হবে।'
              : lang === 'en'
              ? 'Try increasing the maximum monthly fee slider or clearing the Upazila/College filter.'
              : 'মাসিক বাজেট স্লাইডার বাড়িয়ে অথবা ফিল্টার রিসেট করে আবার চেষ্টা করুন।'}
          </p>
          {totalTutorsCount === 0 ? (
            <button
              type="button"
              onClick={onSwitchToUploadDesk}
              className="inline-block px-5 py-2.5 rounded-xl bg-[#047857] text-white text-xs font-semibold hover:bg-[#065F46] transition-colors"
            >
              {lang === 'en' ? 'Profile →' : 'প্রোফাইল →'}
            </button>
          ) : (
            <button
              type="button"
              onClick={onResetFilters}
              className="px-5 py-2.5 rounded-xl bg-[#047857] text-white text-xs font-semibold hover:bg-[#065F46] transition-colors"
            >
              {lang === 'en'
                ? 'Reset Discovery Filters'
                : 'সকল ফিল্টার রিসেট করুন'}
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTutors.map((tutor) => {
            const isShortlisted = shortlistedIds.includes(tutor.id);
            const isTrialBooked = bookedTutorIds.includes(tutor.id);
            const isVerified = tutor.nidVerified && tutor.uniIdVerified;
            const subjects =
              lang === 'en' ? tutor.subjectsEn : tutor.subjectsBn;
            const areas =
              lang === 'en' ? tutor.coveredAreasEn : tutor.coveredAreasBn;

            return (
              <article
                key={tutor.id}
                className="rounded-2xl bg-white dark:bg-stone-900 border border-stone-200/90 dark:border-stone-800 p-6 flex flex-col justify-between transition-colors hover:border-[#047857]/50"
              >
                <div>
                  {/* Top Row: Portrait + Name + Verification Status + Shortlist & Delete */}
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4">
                      {tutor.profilePhotoUrl ? (
                        <img
                          src={tutor.profilePhotoUrl}
                          alt={`Verified photo of ${tutor.nameEn}`}
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 rounded-full object-cover border-2 border-[#047857]/40 shrink-0 shadow-2xs"
                        />
                      ) : (
                        <TutorPortraitSvg
                          variant={tutor.portraitVariant}
                          className="w-16 h-16"
                        />
                      )}
                      <div>
                        {/* Quiet 1-line Verification Kicker (Zero-Pill Discipline) */}
                        <div className="flex flex-wrap items-center gap-1.5 text-xs font-semibold mb-1">
                          {isVerified ? (
                            <span className="inline-flex items-center gap-1 text-[#047857] dark:text-emerald-400">
                              <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                              <span>
                                {lang === 'en'
                                  ? 'Verified · NID & Uni ID'
                                  : 'ভেরিফায়েড · এনআইডি ও আইডি'}
                              </span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
                              <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                              <span>
                                {lang === 'en'
                                  ? 'Verification Pending'
                                  : 'ভেরিফিকেশন পেন্ডিং'}
                              </span>
                            </span>
                          )}
                          <span aria-hidden="true" className="text-stone-400">
                            ·
                          </span>
                          <span className="text-stone-600 dark:text-stone-400 font-normal">
                            {lang === 'en'
                              ? tutor.upazila
                              : UPAZILA_LABELS[tutor.upazila].bn}
                          </span>
                        </div>

                        <h3 className="text-lg font-bold text-stone-900 dark:text-stone-50 leading-snug">
                          {lang === 'en' ? tutor.nameEn : tutor.nameBn}
                        </h3>

                        <p className="text-xs font-medium text-stone-600 dark:text-stone-300 mt-0.5">
                          {lang === 'en'
                            ? tutor.institutionFullEn
                            : tutor.institutionFullBn}
                        </p>
                      </div>
                    </div>

                    {/* Shortlist Heart & Delete Action */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => onToggleShortlist(tutor.id)}
                        aria-label={
                          isShortlisted
                            ? `Remove ${tutor.nameEn} from shortlist`
                            : `Save ${tutor.nameEn} to shortlist`
                        }
                        aria-pressed={isShortlisted}
                        className={`p-2 rounded-xl border transition-colors ${
                          isShortlisted
                            ? 'bg-amber-500/15 border-amber-500/50 text-amber-600 dark:text-amber-400'
                            : 'bg-[#FAF8F5] dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-400 hover:text-stone-700'
                        }`}
                      >
                        <Heart
                          className={`w-4 h-4 ${
                            isShortlisted ? 'fill-amber-500 text-amber-500' : ''
                          }`}
                        />
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteTutor(tutor.id)}
                        aria-label={`Delete tutor profile ${tutor.nameEn}`}
                        className="p-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-[#FAF8F5] dark:bg-stone-800 text-stone-400 hover:text-red-600 hover:border-red-300 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Visible Average Star Rating & Unboxed Metadata Line */}
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-stone-600 dark:text-stone-400 mt-4 pt-3.5 border-t border-stone-100 dark:border-stone-800">
                    <div className="flex flex-wrap items-center gap-2">
                      {/* Visible Star Rating Display */}
                      <button
                        type="button"
                        onClick={() => onOpenProfileModal(tutor)}
                        className="inline-flex items-center gap-1 font-bold text-stone-900 dark:text-white font-mono-num hover:text-[#047857] dark:hover:text-emerald-400"
                      >
                        <span className="inline-flex items-center">
                          {[1, 2, 3, 4, 5].map((starIdx) => (
                            <Star
                              key={starIdx}
                              className={`w-3.5 h-3.5 ${
                                starIdx <= Math.round(tutor.rating)
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-stone-300 dark:text-stone-600'
                              }`}
                            />
                          ))}
                        </span>
                        <span className="ml-0.5">
                          {lang === 'bn'
                            ? toBanglaNumber(tutor.rating.toFixed(2))
                            : tutor.rating.toFixed(2)}
                        </span>
                        <span className="font-normal text-stone-500">
                          (
                          {lang === 'bn'
                            ? `${toBanglaNumber(tutor.totalReviews)}টি রিভিউ`
                            : `${tutor.totalReviews} reviews`}
                          )
                        </span>
                      </button>

                      <span aria-hidden="true">·</span>
                      <span className="font-mono-num">
                        {lang === 'en'
                          ? `${tutor.experienceYears} yrs exp`
                          : `${toBanglaNumber(tutor.experienceYears)} বছরের অভিজ্ঞতা`}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="inline-flex items-center gap-1">
                        <Clock className="w-3 h-3 text-[#047857] dark:text-emerald-400" />
                        {lang === 'en'
                          ? tutor.responseTimeEn
                          : tutor.responseTimeBn}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onOpenProfileModal(tutor)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-[#047857] dark:text-emerald-400 hover:underline whitespace-nowrap shrink-0"
                    >
                      <MessageSquarePlus className="w-3.5 h-3.5" />
                      <span>
                        {lang === 'en' ? 'Rate & Review' : 'রেটিং ও রিভিউ দিন'}
                      </span>
                    </button>
                  </div>

                  {/* Bio Excerpt */}
                  <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 leading-relaxed mt-3">
                    {lang === 'en' ? tutor.bioEn : tutor.bioBn}
                  </p>

                  {/* Unboxed Subjects & Covered Landmarks */}
                  <div className="mt-4 space-y-1.5 text-xs">
                    <div className="text-stone-700 dark:text-stone-300">
                      <span className="font-semibold text-stone-900 dark:text-stone-100">
                        {lang === 'en' ? 'Subjects: ' : 'পড়ানোর বিষয়: '}
                      </span>
                      <span>{subjects.join(' · ')}</span>
                    </div>
                    <div className="text-stone-600 dark:text-stone-400">
                      <span className="font-semibold text-stone-800 dark:text-stone-200">
                        {lang === 'en' ? 'Service Areas: ' : 'কভারেজ এলাকা: '}
                      </span>
                      <span>{areas.join(' · ')}</span>
                    </div>
                  </div>
                </div>

                {/* Card Footer: Monthly Fee + Full Profile & Reviews Modal + Book 2 Free Trial Classes */}
                <div className="mt-5 pt-4 border-t border-stone-200/80 dark:border-stone-800 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <span className="block text-[11px] text-stone-500 dark:text-stone-400">
                      {lang === 'en' ? 'Monthly Honorarium' : 'মাসিক সম্মানী'}
                    </span>
                    <span className="text-lg font-extrabold font-mono-num text-stone-900 dark:text-white">
                      {formatBDT(tutor.monthlyFee, lang)}
                    </span>
                    <span className="text-xs text-stone-500 dark:text-stone-400">
                      {lang === 'en' ? ' / month' : ' / মাস'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => onOpenProfileModal(tutor)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-[#FAF8F5] dark:bg-stone-800 hover:bg-stone-200/70 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 border border-stone-200 dark:border-stone-700 text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>
                        {lang === 'en'
                          ? `Profile & Reviews (${tutor.totalReviews})`
                          : `প্রোফাইল ও রিভিউ (${toBanglaNumber(tutor.totalReviews)})`}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenTrialModal(tutor)}
                      className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                        isTrialBooked
                          ? 'bg-amber-500/20 text-amber-900 dark:text-amber-300 border border-amber-500/40'
                          : 'bg-[#047857] hover:bg-[#065F46] text-white'
                      }`}
                    >
                      {isTrialBooked ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#047857] dark:text-emerald-400" />
                          <span>
                            {lang === 'en'
                              ? 'Trial Requested'
                              : 'ট্রায়াল বুক হয়েছে'}
                          </span>
                        </>
                      ) : (
                        <>
                          <CalendarCheck className="w-3.5 h-3.5" />
                          <span>
                            {lang === 'en'
                              ? 'Book 2 Free Trial Classes'
                              : '২টি ফ্রি ট্রায়াল ক্লাস বুক করুন'}
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
};
