import React from 'react';
import {
  MADARIPUR_UPAZILAS,
  TUTORING_MODES_META,
  UI_COPY,
  UPAZILA_LABELS,
} from '../data/madaripurData';
import {
  CollegeTag,
  FilterState,
  Language,
  MediumCategory,
  TutoringMode,
  TutorGender,
  TutorProfile,
  Upazila,
} from '../types/madaripur';
import { toBanglaNumber } from '../utils/tutorEngine';
import { MadaripurEditorialSceneSvg } from './TutorPortraitSvg';
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  Heart,
  MapPin,
  Moon,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Sun,
  UserCheck,
  Zap,
} from 'lucide-react';

interface BentoHeroProps {
  lang: Language;
  onToggleLang: (lang: Language) => void;
  darkMode: boolean;
  onToggleDark: () => void;
  selectedUpazila: Upazila;
  onSelectUpazila: (upazila: Upazila) => void;
  selectedMode: TutoringMode;
  onSelectMode: (mode: TutoringMode) => void;
  shortlistCount: number;
  shortlistedOnly: boolean;
  onToggleShortlistedOnly: () => void;
  tutors: TutorProfile[];
  bookedTrialsCount: number;
  onOpenTutorUploadDesk: () => void;
  onOpenTutorBoardDesk: () => void;
  onOpenJobBoardDesk?: () => void;
  onOpenGuardianModal?: () => void;
  filters?: FilterState;
  onUpdateFilters?: (partial: Partial<FilterState>) => void;
}

const HERO_COLLEGE_TAGS: CollegeTag[] = [
  'All',
  'Govt. Nazimuddin College',
  'Madaripur Govt. College',
  'DU',
  'BUET',
  'Medical',
];

export const BentoHero: React.FC<BentoHeroProps> = ({
  lang,
  onToggleLang,
  darkMode,
  onToggleDark,
  selectedUpazila,
  onSelectUpazila,
  selectedMode,
  onSelectMode,
  shortlistCount,
  shortlistedOnly,
  onToggleShortlistedOnly,
  tutors,
  bookedTrialsCount,
  onOpenTutorUploadDesk,
  onOpenTutorBoardDesk,
  onOpenJobBoardDesk,
  onOpenGuardianModal,
  filters,
  onUpdateFilters,
}) => {
  const [isHeroFilterOpen, setIsHeroFilterOpen] = React.useState(false);
  const [heroSearch, setHeroSearch] = React.useState(filters?.searchQuery || '');
  const [heroMediumMode, setHeroMediumMode] = React.useState<string>('All');
  const [heroGender, setHeroGender] = React.useState<TutorGender>(
    filters?.gender || 'All'
  );
  const [heroCollege, setHeroCollege] = React.useState<CollegeTag>(
    filters?.college || 'All'
  );
  const [heroMaxFee, setHeroMaxFee] = React.useState<number>(
    filters?.maxBudget || 10000
  );

  React.useEffect(() => {
    if (filters?.searchQuery !== undefined) {
      setHeroSearch(filters.searchQuery);
    }
  }, [filters?.searchQuery]);

  const activeHeroFilterCount =
    (heroSearch.trim() ? 1 : 0) +
    (selectedUpazila !== 'All' ? 1 : 0) +
    (heroMediumMode !== 'All' ? 1 : 0) +
    (heroGender !== 'All' ? 1 : 0) +
    (heroCollege !== 'All' ? 1 : 0) +
    (heroMaxFee < 10000 ? 1 : 0);

  const handleResetHeroFilters = () => {
    setHeroSearch('');
    setHeroMediumMode('All');
    setHeroGender('All');
    setHeroCollege('All');
    setHeroMaxFee(10000);
    onSelectUpazila('All');
    onSelectMode('All');
    onUpdateFilters?.({
      searchQuery: '',
      upazila: 'All',
      medium: 'All',
      mode: 'All',
      gender: 'All',
      college: 'All',
      maxBudget: 10000,
    });
  };

  const copy = UI_COPY[lang];
  const allUpazilas: Upazila[] = ['All', ...MADARIPUR_UPAZILAS];

  const verifiedTutorsCount = tutors.filter(
    (t) => t.nidVerified && t.uniIdVerified
  ).length;

  const getUpazilaTutorCount = (upz: Upazila) => {
    if (upz === 'All') return tutors.length;
    return tutors.filter((t) => t.upazila === upz).length;
  };

  return (
    <section
      aria-label="Tutor Zone Platform Overview"
      className="max-w-[1280px] mx-auto px-3.5 sm:px-6 lg:px-8 pt-2.5 sm:pt-4 pb-10"
    >
      {/* Compact Workspace Utility Strip (Single Language Toggle, Shortlist Counter, Dark Mode Toggle on One Line) */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 pb-3 mb-4 border-b border-stone-200/80 dark:border-stone-800">
        {/* Condensed Single-Line Tagline Badge */}
        <div className="inline-flex items-center gap-1.5 text-[11px] sm:text-xs text-stone-600 dark:text-stone-400 truncate">
          <MapPin className="w-3.5 h-3.5 text-[#047857] dark:text-emerald-400 shrink-0" />
          <span className="font-semibold text-stone-700 dark:text-stone-300 truncate">
            {copy.districtKicker}
          </span>
        </div>

        {/* Single-Row Utility Bar: Language Toggle + Shortlisted (0) + Dark Mode */}
        <div className="flex items-center justify-between md:justify-end gap-2 w-full md:w-auto">
          {/* Single Language Toggle Button */}
          <button
            type="button"
            onClick={() => onToggleLang(lang === 'en' ? 'bn' : 'en')}
            aria-label={
              lang === 'en'
                ? 'Switch language to Bangla'
                : 'Switch language to English'
            }
            className="px-3 py-1.5 rounded-full text-xs font-bold border border-slate-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-slate-800 dark:text-stone-200 hover:border-emerald-600/50 shadow-xs flex items-center gap-1.5 shrink-0 whitespace-nowrap transition-colors cursor-pointer"
          >
            <span aria-hidden="true">🌐</span>
            <span className={lang === 'en' ? 'font-bangla' : ''}>
              {lang === 'en' ? 'বাংলা' : 'English'}
            </span>
          </button>

          {/* Shortlist Filter Toggle Button */}
          <button
            type="button"
            onClick={onToggleShortlistedOnly}
            aria-pressed={shortlistedOnly}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border shadow-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              shortlistedOnly
                ? 'bg-amber-500/15 border-amber-500 text-amber-900 dark:text-amber-300'
                : 'bg-white dark:bg-stone-900 border-slate-200 dark:border-stone-700 text-slate-700 dark:text-stone-300 hover:border-slate-300'
            }`}
          >
            <Heart
              className={`w-3.5 h-3.5 shrink-0 ${
                shortlistCount > 0
                  ? 'fill-amber-500 text-amber-500'
                  : 'text-stone-400'
              }`}
            />
            <span>
              {lang === 'en' ? 'Shortlisted' : 'পছন্দের তালিকা'} (
              <span className="font-mono-num">
                {lang === 'bn' ? toBanglaNumber(shortlistCount) : shortlistCount}
              </span>
              )
            </span>
          </button>

          {/* Dark Mode Toggle */}
          <button
            type="button"
            onClick={onToggleDark}
            aria-label={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-white dark:bg-stone-900 border border-slate-200 dark:border-stone-700 text-slate-700 dark:text-stone-300 hover:border-slate-300 dark:hover:border-stone-600 shadow-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {darkMode ? (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{lang === 'en' ? 'Ivory Light' : 'লাইট মোড'}</span>
              </>
            ) : (
              <>
                <Moon className="w-3.5 h-3.5 text-stone-600 dark:text-stone-300 shrink-0" />
                <span>{lang === 'en' ? 'Dark Mode' : 'ডার্ক মোড'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* ASYMMETRIC BENTO GRID: ROW 1 (7 Cols Editorial Proposition + 5 Cols Spotlight & Metrics) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Left Bento Card (7 Cols): Main Headline + 1-Click Upazila Filter Chips */}
        <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200/90 dark:border-stone-800 p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-[#047857] dark:text-emerald-400 mb-3">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>
                {lang === 'en'
                  ? 'Manual NID & University ID Verification Workflow'
                  : 'এনআইডি ও বিশ্ববিদ্যালয় আইডি কার্ড যাচাইকৃত'}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {lang === 'en'
                  ? 'Verified Guardian Reviews'
                  : 'অভিভাবক স্টার রেটিং ও রিভিউ'}
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-tight text-slate-900 dark:text-stone-50 mb-6 text-balance">
              {lang === 'en' ? (
                <>
                  <span className="bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">
                    Verified
                  </span>{' '}
                  <span className="text-slate-900 dark:text-stone-50">
                    home &amp;{' '}
                    <span className="relative inline-block">
                      online tutors
                      <span
                        aria-hidden="true"
                        className="absolute -bottom-1.5 left-0 right-0 h-1.5 rounded-full bg-gradient-to-r from-emerald-500/35 to-teal-500/35"
                      />
                    </span>
                  </span>
                </>
              ) : (
                <>
                  <span className="bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">
                    যাচাইকৃত
                  </span>{' '}
                  <span className="text-slate-900 dark:text-stone-50">
                    হোম ও{' '}
                    <span className="relative inline-block">
                      অনলাইন টিউটর
                      <span
                        aria-hidden="true"
                        className="absolute -bottom-1.5 left-0 right-0 h-1.5 rounded-full bg-gradient-to-r from-emerald-500/35 to-teal-500/35"
                      />
                    </span>
                  </span>
                </>
              )}
            </h1>
          </div>

          {/* 1-Click Upazila Filter Controls & Collapsible Filter Bar */}
          <div className="pt-3 border-t border-stone-200/80 dark:border-stone-800">
            {/* Compact Search + "⚙️ Filter" Toggle Bar */}
            <div className="flex items-center gap-2 mb-2">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 dark:text-stone-500 pointer-events-none" />
                <input
                  type="text"
                  value={heroSearch}
                  onChange={(e) => {
                    const val = e.target.value;
                    setHeroSearch(val);
                    onUpdateFilters?.({ searchQuery: val });
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      onOpenTutorBoardDesk();
                    }
                  }}
                  placeholder={
                    lang === 'en'
                      ? 'Search Tutor, Subject, or College...'
                      : 'টিউটর, বিষয় বা কলেজ খুঁজুন...'
                  }
                  className="w-full py-2 pl-8 pr-3 text-xs rounded-xl bg-slate-50 dark:bg-stone-800 border border-slate-200 dark:border-stone-700 text-slate-800 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-1 focus:ring-emerald-600 focus:border-emerald-600 transition-colors"
                />
              </div>

              <button
                type="button"
                onClick={() => setIsHeroFilterOpen((prev) => !prev)}
                aria-expanded={isHeroFilterOpen}
                aria-label="Toggle Hero Filters"
                className={`px-3 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 shrink-0 shadow-xs transition-colors cursor-pointer ${
                  isHeroFilterOpen || activeHeroFilterCount > 0
                    ? 'bg-emerald-700 text-white hover:bg-emerald-800'
                    : 'bg-emerald-700/90 hover:bg-emerald-800 text-white'
                }`}
              >
                <SlidersHorizontal className="w-3.5 h-3.5 shrink-0" />
                <span>⚙️ {lang === 'en' ? 'Filter' : 'ফিল্টার'}</span>
                {activeHeroFilterCount > 0 && (
                  <span className="w-4 h-4 rounded-full bg-white text-emerald-800 text-[10px] font-extrabold flex items-center justify-center font-mono-num ml-0.5">
                    {lang === 'bn'
                      ? toBanglaNumber(activeHeroFilterCount)
                      : activeHeroFilterCount}
                  </span>
                )}
              </button>

              {activeHeroFilterCount > 0 && (
                <button
                  type="button"
                  onClick={handleResetHeroFilters}
                  title={lang === 'en' ? 'Reset Filters' : 'ফিল্টার রিসেট'}
                  className="px-2.5 py-2 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 hover:bg-rose-100 shrink-0 transition-colors cursor-pointer"
                >
                  {lang === 'en' ? 'Reset' : 'মুছুন'}
                </button>
              )}
            </div>

            {/* Collapsible 2-Column Compact Filter Drawer */}
            {isHeroFilterOpen && (
              <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-50/90 dark:bg-stone-800/80 rounded-xl border border-slate-200 dark:border-stone-700 my-2 text-xs">
                {/* 1. Upazila Dropdown */}
                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-500 dark:text-stone-400 mb-1">
                    {lang === 'en' ? 'Upazila / Area' : 'উপজেলা / এলাকা'}
                  </label>
                  <select
                    value={selectedUpazila}
                    onChange={(e) => {
                      const upz = e.target.value as Upazila;
                      onSelectUpazila(upz);
                      onUpdateFilters?.({ upazila: upz });
                    }}
                    className="w-full py-1.5 px-2 text-xs font-semibold rounded-lg bg-white dark:bg-stone-900 border border-slate-200 dark:border-stone-700 text-slate-800 dark:text-stone-100 focus:outline-none focus:ring-1 focus:ring-emerald-600"
                  >
                    {allUpazilas.map((u) => (
                      <option key={u} value={u}>
                        {lang === 'en' ? UPAZILA_LABELS[u].en : UPAZILA_LABELS[u].bn}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Medium / Mode Dropdown */}
                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-500 dark:text-stone-400 mb-1">
                    {lang === 'en' ? 'Medium / Mode' : 'মাধ্যম / মোড'}
                  </label>
                  <select
                    value={heroMediumMode}
                    onChange={(e) => {
                      const val = e.target.value;
                      setHeroMediumMode(val);
                      if (val === 'Home' || val === 'Online') {
                        onSelectMode(val as TutoringMode);
                        onUpdateFilters?.({ mode: val as TutoringMode, medium: 'All' });
                      } else if (
                        val === 'Bangla Medium' ||
                        val === 'English Version'
                      ) {
                        onSelectMode('All');
                        onUpdateFilters?.({
                          medium: val as MediumCategory,
                          mode: 'All',
                        });
                      } else {
                        onSelectMode('All');
                        onUpdateFilters?.({ medium: 'All', mode: 'All' });
                      }
                    }}
                    className="w-full py-1.5 px-2 text-xs font-semibold rounded-lg bg-white dark:bg-stone-900 border border-slate-200 dark:border-stone-700 text-slate-800 dark:text-stone-100 focus:outline-none focus:ring-1 focus:ring-emerald-600"
                  >
                    <option value="All">
                      {lang === 'en' ? 'All Modes & Mediums' : 'সকল মাধ্যম ও মোড'}
                    </option>
                    <option value="Bangla Medium">
                      {lang === 'en' ? 'Bangla Medium' : 'বাংলা মাধ্যম'}
                    </option>
                    <option value="English Version">
                      {lang === 'en' ? 'English Version' : 'ইংলিশ ভার্সন'}
                    </option>
                    <option value="Home">
                      {lang === 'en' ? 'Home Tutoring' : 'হোম টিউশনি'}
                    </option>
                    <option value="Online">
                      {lang === 'en' ? 'Online Live Class' : 'অনলাইন ক্লাস'}
                    </option>
                  </select>
                </div>

                {/* 3. Tutor Gender Compact Pills */}
                <div>
                  <label className="block text-[10px] font-bold uppercase text-stone-500 dark:text-stone-400 mb-1">
                    {lang === 'en' ? 'Tutor Gender' : 'টিউটর জেন্ডার'}
                  </label>
                  <div className="flex items-center gap-1">
                    {(['All', 'Male', 'Female'] as TutorGender[]).map((g) => {
                      const isSel = heroGender === g;
                      return (
                        <button
                          key={g}
                          type="button"
                          onClick={() => {
                            setHeroGender(g);
                            onUpdateFilters?.({ gender: g });
                          }}
                          className={`flex-1 py-1 text-[11px] font-bold rounded-lg border text-center transition-colors cursor-pointer ${
                            isSel
                              ? 'bg-emerald-700 text-white border-emerald-700'
                              : 'bg-white dark:bg-stone-900 text-slate-700 dark:text-stone-300 border-slate-200 dark:border-stone-700 hover:border-emerald-300'
                          }`}
                        >
                          {g === 'All'
                            ? lang === 'en'
                              ? 'All'
                              : 'সব'
                            : g === 'Male'
                            ? lang === 'en'
                              ? 'Male'
                              : 'পুরুষ'
                            : lang === 'en'
                            ? 'Female'
                            : 'মহিলা'}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 4. Institution Selector & Max Budget Slider */}
                <div>
                  <div className="flex items-center justify-between text-[10px] font-bold uppercase text-stone-500 dark:text-stone-400 mb-1">
                    <span>{lang === 'en' ? 'Institution' : 'প্রতিষ্ঠান'}</span>
                    <span className="font-mono-num text-emerald-700 dark:text-emerald-400 lowercase">
                      ৳{lang === 'bn' ? toBanglaNumber(heroMaxFee) : heroMaxFee}/m
                    </span>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <select
                      value={heroCollege}
                      onChange={(e) => {
                        const col = e.target.value as CollegeTag;
                        setHeroCollege(col);
                        onUpdateFilters?.({ college: col });
                      }}
                      className="w-full py-1.5 px-2 text-xs font-semibold rounded-lg bg-white dark:bg-stone-900 border border-slate-200 dark:border-stone-700 text-slate-800 dark:text-stone-100 focus:outline-none focus:ring-1 focus:ring-emerald-600"
                    >
                      {HERO_COLLEGE_TAGS.map((col) => (
                        <option key={col} value={col}>
                          {col === 'All'
                            ? lang === 'en'
                              ? 'All Colleges/Unis'
                              : 'সকল কলেজ/ভার্সিটি'
                            : col}
                        </option>
                      ))}
                    </select>
                    <input
                      type="range"
                      min={1000}
                      max={15000}
                      step={500}
                      value={heroMaxFee}
                      onChange={(e) => {
                        const fee = Number(e.target.value);
                        setHeroMaxFee(fee);
                        onUpdateFilters?.({ maxBudget: fee });
                      }}
                      className="w-full accent-emerald-600 h-1.5 cursor-pointer bg-slate-200 dark:bg-stone-700 rounded-lg"
                      aria-label="Max Monthly Budget"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Single-Line Horizontal Scrollable Area Chips */}
            <div className="text-[11px] font-bold mb-1.5 flex items-center justify-between gap-2">
              <span className="text-stone-700 dark:text-stone-300">
                {copy.upazilaFilterLabel}
              </span>
              <span className="text-stone-500 dark:text-stone-400 font-semibold">
                {lang === 'en'
                  ? `Active filter: ${UPAZILA_LABELS[selectedUpazila].en}`
                  : `নির্বাচিত এলাকা: ${UPAZILA_LABELS[selectedUpazila].bn}`}
              </span>
            </div>

            <div
              role="group"
              aria-label="Filter tutors by Madaripur Upazila"
              className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 whitespace-nowrap mb-2"
            >
              {allUpazilas.map((upz) => {
                const active = selectedUpazila === upz;
                const info = UPAZILA_LABELS[upz];
                const liveCount = getUpazilaTutorCount(upz);
                return (
                  <button
                    key={upz}
                    type="button"
                    onClick={() => {
                      onSelectUpazila(upz);
                      onUpdateFilters?.({ upazila: upz });
                    }}
                    className={`px-3 py-1.5 text-xs font-bold rounded-full shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
                      active
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-slate-100/90 dark:bg-stone-800/90 text-slate-700 dark:text-stone-200 border border-slate-200/80 dark:border-stone-700 hover:border-emerald-300'
                    }`}
                  >
                    <span>{lang === 'en' ? info.en : info.bn}</span>
                    <span
                      className={`font-mono-num text-[11px] ${
                        active
                          ? 'text-emerald-100'
                          : 'text-stone-400 dark:text-stone-400'
                      }`}
                    >
                      ({lang === 'bn' ? toBanglaNumber(liveCount) : liveCount})
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Primary CTA & Secondary Action: Side-by-Side Compact Action Buttons */}
            <div className="flex items-center gap-2 mt-2.5">
              <button
                type="button"
                onClick={onOpenTutorBoardDesk}
                className="flex-1 py-2.5 px-3 text-xs sm:text-sm font-bold rounded-xl flex items-center justify-center gap-1.5 bg-[#047857] hover:bg-[#065F46] text-white shadow-xs transition-colors whitespace-nowrap cursor-pointer"
              >
                <BookOpen className="w-4 h-4 shrink-0" />
                <span>
                  {lang === 'en'
                    ? 'Explore Verified Tutors'
                    : 'যাচাইকৃত টিউটর তালিকা দেখুন'}
                </span>
              </button>

              <button
                type="button"
                onClick={onOpenTutorUploadDesk}
                className="py-2.5 px-3.5 text-xs sm:text-sm font-bold rounded-xl shrink-0 inline-flex items-center justify-center gap-1 bg-amber-500/15 hover:bg-amber-500/25 text-amber-900 dark:text-amber-300 border border-amber-500/40 transition-colors whitespace-nowrap cursor-pointer"
              >
                <span>
                  {lang === 'en' ? 'Profile' : 'প্রোফাইল'}
                </span>
                <ArrowUpRight className="w-4 h-4 shrink-0" />
              </button>
            </div>

            {/* Prominent Guardian Request Button */}
            {onOpenGuardianModal && (
              <button
                type="button"
                onClick={onOpenGuardianModal}
                className="w-full mt-2.5 py-3 px-4 text-xs sm:text-sm font-extrabold rounded-xl flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-800 text-white shadow-md hover:shadow-lg transition-all cursor-pointer border border-emerald-500/30"
              >
                <UserCheck className="w-4.5 h-4.5 shrink-0 text-amber-300" />
                <span>
                  {lang === 'en'
                    ? 'Hire a Verified Tutor (For Guardians)'
                    : 'শিক্ষক খুঁজুন (অভিভাবকদের জন্য)'}
                </span>
                <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
              </button>
            )}
          </div>
        </div>

        {/* Right Bento Card (5 Cols): Visual Spotlight + Live Platform Metrics */}
        <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200/90 dark:border-stone-800 p-6 flex flex-col justify-between gap-5">
          <div>
            <MadaripurEditorialSceneSvg />
            <div className="p-2.5 sm:px-4 rounded-2xl bg-gradient-to-r from-emerald-50/90 via-white to-teal-50/80 dark:from-emerald-950/40 dark:via-stone-900 dark:to-teal-950/30 border border-emerald-200/90 dark:border-emerald-800/80 shadow-sm hover:shadow-md hover:border-emerald-300 dark:hover:border-emerald-700 transition-all flex items-center justify-between gap-3 my-2 backdrop-blur-xs">
              <div className="flex items-center gap-2 min-w-0">
                <span className="relative flex h-2.5 w-2.5 shrink-0">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-600 dark:bg-emerald-400" />
                </span>
                <div className="w-7 h-7 rounded-lg bg-emerald-100/80 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0">
                  <Sparkles className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs sm:text-sm font-extrabold tracking-tight bg-gradient-to-r from-slate-900 to-emerald-800 dark:from-white dark:to-emerald-300 bg-clip-text text-transparent whitespace-nowrap">
                  {lang === 'en' ? 'Direct link of' : 'সরাসরি লিংক'}
                </span>
              </div>
              <button
                type="button"
                onClick={onOpenTutorBoardDesk}
                className="px-4 py-2 rounded-full bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white text-xs sm:text-sm font-extrabold shadow-md shadow-emerald-600/25 hover:shadow-lg hover:shadow-emerald-600/35 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 flex items-center gap-1.5 shrink-0 cursor-pointer group"
              >
                <span>{lang === 'en' ? 'Tutor Board' : 'টিউটর বোর্ড'}</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform shrink-0" />
              </button>
            </div>
          </div>

          {/* Second Premium Visual Showcase Banner: Live Tutor Match & Scholar Spotlight */}
          <div className="pt-2 border-t border-stone-200/80 dark:border-stone-800">
            <div className="rounded-2xl overflow-hidden bg-gradient-to-br from-slate-900 via-emerald-950 to-teal-900 p-4 relative shadow-lg border border-emerald-500/20 select-none">
              {/* Glowing Ambient Emerald & Gold Mesh Circles in Background */}
              <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-emerald-500/25 blur-3xl pointer-events-none" />
              <div className="absolute -bottom-10 -left-10 w-44 h-44 rounded-full bg-amber-400/15 blur-3xl pointer-events-none" />
              <div className="absolute top-1/2 left-1/3 -translate-y-1/2 w-32 h-32 rounded-full bg-teal-400/15 blur-2xl pointer-events-none" />
              <svg
                className="absolute inset-0 w-full h-full opacity-10 pointer-events-none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <defs>
                  <pattern id="scholar-grid" width="24" height="24" patternUnits="userSpaceOnUse">
                    <path d="M 24 0 L 0 0 0 24" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.5" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#scholar-grid)" />
              </svg>

              {/* Header: Glowing "⚡ Instant Tutor Match" Badge & Scholar Spotlight Indicator */}
              <div className="flex items-center justify-between gap-2 mb-3 relative z-10">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gradient-to-r from-emerald-500/30 to-teal-500/20 border border-emerald-400/40 text-emerald-300 text-[11px] font-extrabold tracking-wide shadow-sm shadow-emerald-500/20">
                  <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300 animate-pulse" />
                  <span>
                    {lang === 'en'
                      ? '⚡ Instant Tutor Match'
                      : '⚡ ইনস্ট্যান্ট টিউটর ম্যাচ'}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] text-emerald-300/90 font-bold">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
                  </span>
                  <span className="hidden sm:inline">
                    {lang === 'en'
                      ? 'Scholar Spotlight'
                      : 'স্কলার স্পটলাইট'}
                  </span>
                </div>
              </div>

              {/* Floating Verified Tutor Avatar Cards with University Badges (DU, BUET, DMC) & 5-Star Pills */}
              <div className="relative z-10 flex flex-col gap-2">
                {/* Scholar Card 1: Verified Scholar Hub (Featured Wide Card) */}
                <div className="p-2.5 rounded-xl bg-white/10 dark:bg-black/30 backdrop-blur-md border border-emerald-500/30 hover:border-emerald-400/60 transition-all flex items-center justify-between gap-2 shadow-sm">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="relative w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-300 p-0.5 shrink-0 shadow-xs">
                      <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center text-white font-extrabold text-xs">
                        TZ
                      </div>
                      <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-900 flex items-center justify-center">
                        <CheckCircle2 className="w-2.5 h-2.5 text-white stroke-[3]" />
                      </div>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-extrabold text-white truncate">
                          {lang === 'en' ? 'Verified Scholar Hub' : 'ভেরিফাইড স্কলার হাব'}
                        </span>
                        <span className="px-1.5 py-0.5 rounded-md text-[10px] font-extrabold bg-cyan-500/25 border border-cyan-400/40 text-cyan-200 font-mono-num">
                          BUET
                        </span>
                      </div>
                      <span className="text-[11px] text-emerald-200/80 font-medium truncate block">
                        {lang === 'en' ? 'BUET · DU · Medical Tutors' : 'বুয়েট · ঢাবি · মেডিকেল টিউটর'}
                      </span>
                    </div>
                  </div>
                  <div className="shrink-0 flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-[10px] font-extrabold font-mono-num whitespace-nowrap shadow-xs">
                    <span>★ 5.0</span>
                    <span className="hidden sm:inline font-semibold text-amber-200/90">
                      Top Rated
                    </span>
                  </div>
                </div>

                {/* Scholar Cards 2 & 3: Madaripur Sadar Hub & Online Live Desk (Side-by-Side 2-Column Grid) */}
                <div className="grid grid-cols-2 gap-2">
                  {/* Madaripur Sadar Hub */}
                  <div className="p-2.5 rounded-xl bg-white/10 dark:bg-black/30 backdrop-blur-md border border-white/15 hover:border-emerald-400/40 transition-all flex flex-col justify-between gap-1 shadow-sm">
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <div className="relative w-6 h-6 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-400 p-0.5 shrink-0">
                          <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center text-white font-bold text-[10px]">
                            MS
                          </div>
                        </div>
                        <span className="px-1.5 py-0.5 rounded-md text-[10px] font-extrabold bg-indigo-500/25 border border-indigo-400/40 text-indigo-200 font-mono-num">
                          DU
                        </span>
                      </div>
                      <span className="text-[10px] font-extrabold text-amber-300 font-mono-num shrink-0">
                        ★ 5.0
                      </span>
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">
                        {lang === 'en' ? 'Madaripur Sadar Hub' : 'মাদারীপুর সদর হাব'}
                      </div>
                      <div className="text-[10px] text-slate-300/80 truncate">
                        {lang === 'en' ? '100% ID Verified Profile' : '১০০% আইডি যাচাইকৃত প্রোফাইল'}
                      </div>
                    </div>
                  </div>

                  {/* Online Live Desk */}
                  <div className="p-2.5 rounded-xl bg-white/10 dark:bg-black/30 backdrop-blur-md border border-white/15 hover:border-emerald-400/40 transition-all flex flex-col justify-between gap-1 shadow-sm">
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <div className="relative w-6 h-6 rounded-full bg-gradient-to-tr from-rose-500 to-amber-400 p-0.5 shrink-0">
                          <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center text-white font-bold text-[10px]">
                            OL
                          </div>
                        </div>
                        <span className="px-1.5 py-0.5 rounded-md text-[10px] font-extrabold bg-rose-500/25 border border-rose-400/40 text-rose-200 font-mono-num">
                          DMC
                        </span>
                      </div>
                      <span className="text-[10px] font-extrabold text-amber-300 font-mono-num shrink-0">
                        ★ 5.0
                      </span>
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">
                        {lang === 'en' ? 'Online Live Desk' : 'অনলাইন লাইভ ডেক্স'}
                      </div>
                      <div className="text-[10px] text-slate-300/80 truncate">
                        {lang === 'en' ? 'Interactive Pen-Tab Ready' : 'ইন্টারেক্টিভ পেন-ট্যাব প্যানেল'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* "Direct link of" + "Tuition Circulars →" Frosted-Glass Action Bar */}
            <div className="mt-2.5 p-2.5 sm:px-3.5 rounded-xl bg-gradient-to-r from-emerald-50/80 via-white to-teal-50/60 dark:from-emerald-950/50 dark:via-stone-900 dark:to-teal-950/40 border border-emerald-200/80 dark:border-emerald-800/60 flex items-center justify-between gap-2 shadow-xs">
              <div className="flex items-center gap-2 text-xs sm:text-sm font-extrabold text-slate-800 dark:text-stone-100 min-w-0">
                <span className="relative flex h-2.5 w-2.5 shrink-0">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-600 dark:bg-emerald-400" />
                </span>
                <div className="w-7 h-7 rounded-lg bg-emerald-100/80 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0">
                  <Sparkles className="w-3.5 h-3.5" />
                </div>
                <span className="truncate bg-gradient-to-r from-slate-900 to-emerald-800 dark:from-white dark:to-emerald-300 bg-clip-text text-transparent font-extrabold">
                  {lang === 'en' ? 'Direct link of' : 'সরাসরি লিংক'}
                </span>
              </div>

              <button
                type="button"
                onClick={onOpenJobBoardDesk || onOpenTutorBoardDesk}
                className="px-4 py-2 rounded-full bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white text-xs sm:text-sm font-extrabold shadow-md shadow-emerald-600/25 hover:shadow-lg hover:shadow-emerald-600/35 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 flex items-center gap-1.5 shrink-0 cursor-pointer group"
              >
                <span>
                  {lang === 'en' ? 'Tuition Circulars' : 'টিউশনি সার্কুলার'}
                </span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform shrink-0" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* BENTO ROW 2: 3 COMPACT TUTORING MODE TILES (70% Less Vertical Space, Native Mobile Look) */}
      <div id="modes" className="mt-4 sm:mt-5">
        <div className="flex items-center justify-between gap-2 mb-2">
          <h2 className="text-xs font-bold text-stone-600 dark:text-stone-400 flex items-center gap-1.5">
            <span>{copy.modeSectionLabel}</span>
            {selectedMode !== 'All' && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-extrabold">
                {selectedMode}
              </span>
            )}
          </h2>
          {selectedMode !== 'All' && (
            <button
              type="button"
              onClick={() => onSelectMode('All')}
              className="text-xs font-semibold text-[#047857] dark:text-emerald-400 hover:underline whitespace-nowrap shrink-0"
            >
              {lang === 'en' ? 'Show All' : 'সব দেখুন'}
            </button>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2 sm:gap-3 my-2">
          {TUTORING_MODES_META.map((modeItem) => {
            const isSelected = selectedMode === modeItem.id;
            const modeIcon =
              modeItem.id === 'Home'
                ? '🏠'
                : modeItem.id === 'Online'
                ? '💻'
                : '👥';
            const modeShortTitle =
              lang === 'en'
                ? modeItem.id
                : modeItem.id === 'Home'
                ? 'হোম'
                : modeItem.id === 'Online'
                ? 'অনলাইন'
                : 'গ্রুপ';
            const modeSubLabel =
              modeItem.id === 'Home'
                ? lang === 'en'
                  ? '1-on-1 Home'
                  : '১-অন-১ হোম'
                : modeItem.id === 'Online'
                ? lang === 'en'
                  ? 'Live Pen-Tab'
                  : 'লাইভ পেন-ট্যাব'
                : lang === 'en'
                ? '3–5 Students'
                : '৩–৫ জন ব্যাচ';
            const priceBadge =
              modeItem.id === 'Home'
                ? lang === 'en'
                  ? '৳3k–8k/mo'
                  : '৳৩k–৮k/মাস'
                : modeItem.id === 'Online'
                ? lang === 'en'
                  ? '৳2.2k–6.5k'
                  : '৳২.২k–৬.৫k'
                : lang === 'en'
                ? '৳2k–3.5k'
                : '৳২k–৩.৫k';

            return (
              <button
                key={modeItem.id}
                type="button"
                onClick={() =>
                  onSelectMode(isSelected ? 'All' : modeItem.id)
                }
                aria-pressed={isSelected}
                className={`text-left p-2.5 sm:p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50/30 dark:bg-emerald-950/30 ring-1 ring-emerald-600 dark:ring-emerald-500 shadow-xs'
                    : 'bg-white dark:bg-stone-900 border-slate-200/90 dark:border-stone-800 hover:border-emerald-400/60 text-slate-900 dark:text-stone-100'
                }`}
              >
                <div>
                  {/* Top Row: Crisp Icon + Bold Short Title */}
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-stone-100 truncate flex items-center gap-1">
                      <span>{modeIcon}</span>
                      <span>{modeShortTitle}</span>
                    </span>
                    {isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 shrink-0" />
                    )}
                  </div>

                  {/* Tiny 2-word sub-label on mobile / 1-line description on desktop */}
                  <p className="block sm:hidden text-[10px] text-slate-500 dark:text-stone-400 font-medium truncate mt-0.5">
                    {modeSubLabel}
                  </p>
                  <p className="hidden sm:block text-xs text-slate-500 dark:text-stone-400 line-clamp-1 mt-0.5">
                    {lang === 'en' ? modeItem.descEn : modeItem.descBn}
                  </p>
                </div>

                {/* Bottom Row: Compact Emerald Price Badge */}
                <div className="mt-1.5 pt-1 border-t border-slate-100 dark:border-stone-800/80">
                  <span className="text-[10px] sm:text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50/80 dark:bg-emerald-950/50 px-1.5 py-0.5 rounded-md whitespace-nowrap inline-block">
                    {priceBadge}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
